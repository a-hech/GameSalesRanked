from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal colletion in MongoDB """

    def __init__(self, user, password):
        # initializing mongoclient
        # connection variables
        USER = 'aacuser'
        PASS = '123Abby456'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30380
        DB = 'AAC'
        COL = 'animals'
        
        # initialize connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# method to create and insert a document (implement the c in CRUD)
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data) # data should be dictionary
            # if insert is successful, return true
            return True
        else:
            # if insert is unsuccessful, return exception and false
            raise Exception("Nothing to save, data parameter is empty")
            return False

# method to read and query for documents (implement the r in CRUD)
    def read(self, searchAnimals):
        if searchAnimals:
            # if the command is successful, return the data in a list
            data = self.database.animals.find(searchAnimals, {"_id":False})
            return data
        else:
            # else return an empty list
            data = self.database.animals.find({}, {"_id":False})
            return data
        
# method to query for and change documents
    def update(self, searchAnimals, updateAnimals):
        # if there is data
        if searchAnimals is not None:
            # update all documents that match the queried data
            updatedDocs = self.database.animals.update_many(searchAnimals, {"$set":updateAnimals})
            # return the number of objects modified
            return updatedDocs.modified_count
        
# method to query for and delete documents
    def delete(self, deleteAnimals):
        if deleteAnimals is not None:
            # delete all documents that match the queried data
            deletedDocs = self.database.animals.delete_many(deleteAnimals)
            # return the number of objects deleted
            return deletedDocs.deleted_count
